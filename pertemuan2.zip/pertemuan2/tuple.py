#Tuple adalah kumpulan yang terurut dan tidak dapat diubah
