thislist = ["apple", "banana", "cherry"]
print(thislist)

#beda type
list1 = ["abc", 34, True, 40, "male"]

#mengganti item di list

#Remove hanya mengganti item pertama
thislist = ["apple", "banana", "cherry"]
thislist.remove("banana")
print(thislist)

#looop ist
fruits =['apel']
newlist = ['hello' + for x in fruits]