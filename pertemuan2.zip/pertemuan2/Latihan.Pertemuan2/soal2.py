mahasiswa = ('A001', 'Budi', 'informatika')

#1)Tampilkan nama mahasiswa
print(mahasiswa[1])

#2)tampilkan seluruh tuple dengan perulangan for
mahasiswa = ('A001', 'Budi', 'informatika')
for x in mahasiswa:
 print(x)

 #3)Alasan tuple tidak bisa diubah karena merupakan data yang berurut dengan type data yang sama sehingga tidak bisa diuubah