kelas_A = {"Struktur Data", "Basis Data", "AI", "Pemrograman Web"}
kelas_B = {"Struktur Data", "Machine Learning", "AI", "Cloud Computing"}

#1)Tentukan mata kuliah yang diambil kedua kelas
for x in kelas_A == kelas_B:
    print(x)