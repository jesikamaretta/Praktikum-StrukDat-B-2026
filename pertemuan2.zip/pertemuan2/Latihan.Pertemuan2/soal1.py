angka = [10, 20, 30, 40, 50]
#1)tambahkan angka 60 ke dalam list
angka.append(60)
print(angka)

#2)hapus angka 20
angka = [10, 20, 30, 40, 50]
angka.remove(20)
print(angka)

#3)tampilkan angka tertinggi dan terendah
angka = [10, 20, 30, 40, 50]
max = 10
min = 50
print(max, min)


#4)hitung rata rata
ratarata =  